using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ControlsKitShowcase;

public partial class MainWindow : Window
{
    private int _clickCount;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void OnDownloadClick(object sender, RoutedEventArgs e)
    {
        DownloadButton.ButtonText = $"Clicked {++_clickCount} times";
    }
}
